package com.example.pcmaster

//Clase para demostrar el uso de Geters y Seters en Kotlin. Los geters y setters son mas populares en Java, porque en kotlin se generan automaticamente cuando se accede al valor de
//una propiedad, no obstante se incluyen a continuacion para demostrar su funcionalidad.

class SO {
    var sistemaOperativo:String=""
    get() = field
    set(value){
        field=value
    }
    var arquitectura:String=""
        get() = field
        set(value){
            field=value
        }


}
