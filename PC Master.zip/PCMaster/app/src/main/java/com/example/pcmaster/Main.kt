//Taller de Programación 3
//Profesor: Roberto Abadía
//Alumno: Gerardo Granzella

//PC-MAster es un suite de preventa con opciones de customización rápida para equipos, en donde se pueden seleccionar en su etapa beta, tipo de procesador, cantidad y tipo de memoria


package com.example.pcmaster

fun main(){

    //se incluye memoria para la primer pc
    var memopc1 = Memoria("Kingston", 1333,8,2)
    //se incluye procesador para la primer pc
    var procpc1 = Procesador("AMD", "Ryzen",4.0, oc = true)
    //se crea una instancia de la clase PC usando sobrecarga y añadiendo las memorias y procesador del paso previo
    var pc1=PC("PC-Master","LPTKKQL069",500,memopc1,procpc1)

    //se crea una PC con el constructor base
    var pc2=PC("Abadia Computers", "BM42069", 240)

    //Se definen los detalles del SO usando Setters
    val sisOPpc1=SO()
    sisOPpc1.sistemaOperativo="Windows 10 OEM"
    sisOPpc1.arquitectura = "64 bits"

//se llama a las funciones boot para encender el equipo
    pc1.bootear()
    //Se imprimen los detalles del sistema operativo utilizando getters
    println("Sistema Operativo: ${sisOPpc1.sistemaOperativo}")
    println("Arquitectura: ${sisOPpc1.arquitectura}")

//Sobreescritura de método
    if (pc2.procesador.clock==0.0){
        println(pc2)

    }else{
        pc2.bootear()
    }


}