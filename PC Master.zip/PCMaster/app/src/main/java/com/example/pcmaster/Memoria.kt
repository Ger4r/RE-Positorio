package com.example.pcmaster

open class Memoria {


    var marca: String = ""
    var frecuencia: Int = 0
    var capacidad: Int = 0
    var cantidad: Int = 0

    constructor (marca: String, frecuencia: Int,capacidad:Int, cantidad:Int) {
        this.marca=marca
        this.frecuencia=frecuencia
        this.capacidad=capacidad
        this.cantidad=cantidad
    }

    fun dualChannel() {
        if (cantidad >= 2) {
            println("Memoria Instalada: ${this.capacidad*cantidad} Ghz - Modo: Dual Channel @ Frecuencia: ${this.frecuencia}")
        } else
            if (cantidad == 0) {
                println("La PC no cuenta con memoria instalada")
            } else
                println("Memoria Instalada:${this.capacidad} Modo: Single Channel @ Frecuencia: ${this.frecuencia}")
    }
}