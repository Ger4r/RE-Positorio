package com.example.pcmaster


class PC {
    var fabricante:String =""
        get()=field
        set(value) {
            field=value
        }
    var serie:String = ""
    var disco:Int=0
    var memoria:Memoria
    var procesador:Procesador

    //constructor objeto simple
    constructor(fabricante: String, serie: String, disco: Int){
        this.fabricante=fabricante
        this.serie = serie
        this.disco=disco
        this.memoria= Memoria("",0,0,0)
        this.procesador= Procesador("","",0.0, false)

    }

    //Sobrecarga de constructor con relacion de composición
    constructor(fabricante:String, serie:String, disco:Int, memoria: Memoria, procesador: Procesador) {
        this.fabricante = fabricante
        this.serie = serie
        this.disco = disco
        this.memoria = memoria
        this.procesador = procesador

    }


    //la funcion bootear valida que el equipo tenga los recursos de hardware necesarios para inicializar
    open fun bootear(){
        if(procesador.clock == 0.0){
            println("La PC S/N: ${this.serie} no puede bootear sin procesador")

        }else
            if (memoria.frecuencia == 0){
                println("\"La PC S/N: ${this.serie} no puede bootear sin memoria")
//si todos los recursos estan presentes, el sistema procede a encender, se invocan los metodos locales y los de las otras clases
            }else {
                println("Inicializando ${this.fabricante} S/N: ${this.serie}")
                procesador.procData()
                memoria.dualChannel()
                capacidadDisco()
                }


    }

    // Se sobreescribe el metodo, añadiendo parametros adicionales
    override fun toString():String {
        //Reutiliza el metodo boot, y agrega funcionalidad adicional
        bootear()
        return "Error: Faltan componentes y su PC no podrá inicializar. \nPor favor, agregue los componentes restantes o contacte al area de soporte de preventa"

    }
//metodos locacles de información complementaria

    open fun capacidadDisco(){
        println("La capacidad del disco es de ${this.disco} GB")
    }



}


