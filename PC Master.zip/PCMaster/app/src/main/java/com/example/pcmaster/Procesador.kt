package com.example.pcmaster


open class Procesador {

    var marca: String = ""
    var modelo: String = ""
    var clock: Double = 0.0
    var oc: Boolean = false


    constructor (marca: String, modelo:String,clock:Double,oc:Boolean) {
        this.marca=marca
        this.modelo=modelo
        this.clock=clock
        this.oc=oc
    }

    fun procData(){
        if (this.oc){
            println(overClock())
            println("Procesador Marca: ${this.marca}, Modelo: ${this.modelo} @ Clock: ${this.clock} Ghz")

        }else
        println("Procesador Marca: ${this.marca}, Modelo: ${this.modelo} @ Clock: ${this.clock} Ghz")
    }

    fun overClock(){

        println ("Overclock activo, incremento en 20%, el clock actual es de ${this.clock*20/100+clock} Ghz")
    }

}